import java.awt.event.*; import javax.swing.*;
public class CloseButtonTest extends JFrame {
private JPanel p; Icon ani; JButton b;
public CloseButtonTest(String title) {
super(title);
p = new JPanel();
ani = new ImageIcon("Course.gif");
b = new JButton("Close", ani);
b.addActionListener(new ButtonListener());
p.add(b); add(p);
}
private class ButtonListener implements ActionListener {
public void actionPerformed(ActionEvent e) {
if (e.getSource() == b) {
JOptionPane.showMessageDialog(null, "See You Again !!!");
System.exit(0);
}
}
}
public static void main(String args[]) {
CloseButtonTest b = new CloseButtonTest("Button Test");
b.setSize(170, 90);
b.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
b.setVisible(true);
}
}