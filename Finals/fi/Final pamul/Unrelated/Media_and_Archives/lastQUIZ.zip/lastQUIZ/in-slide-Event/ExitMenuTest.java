import javax.swing.*;
import java.awt.event.*;
public class ExitMenuTest extends JFrame {
JMenuBar menubar; JMenu menuFile;
JMenuItem menuExit;
public ExitMenuTest(String title) {
super(title);
menubar = new JMenuBar();
menuFile = new JMenu("File");
menuExit = new JMenuItem("Exit", new ImageIcon("Course.gif"));
menuFile.add(menuExit);
menubar.add(menuFile);
setJMenuBar(menubar);
menuExit.addActionListener(new MenuListener());
}
private class MenuListener implements ActionListener {
public void actionPerformed(ActionEvent e) {
Object source = e.getSource();
if (source == menuExit) {
System.exit(0);
}
}
}
public static void main(String args[]) {
ExitMenuTest f = new ExitMenuTest("Menu Test");
f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
f.setSize(200, 200);
f.setVisible(true);
}
}