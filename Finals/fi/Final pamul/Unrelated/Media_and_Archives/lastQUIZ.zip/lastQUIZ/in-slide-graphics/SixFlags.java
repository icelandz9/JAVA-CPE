import java.awt.*;
import javax.swing.*;

public class SixFlags extends JFrame {
    public SixFlags() {
        Image image1 = new ImageIcon("D:/SWU/CPE121/1.jpg").getImage();
        Image image2 = new ImageIcon("D:/SWU/CPE121/2.jpg").getImage();
        Image image3 = new ImageIcon("D:/SWU/CPE121/3.jpg").getImage();
        Image image4 = new ImageIcon("D:/SWU/CPE121/4.jpg").getImage();
        Image image5 = new ImageIcon("D:/SWU/CPE121/5.jpg").getImage();
        Image image6 = new ImageIcon("D:/SWU/CPE121/6.jpg").getImage();
        setLayout(new GridLayout(2, 3, 5, 5));
        add(new ImageViewer(image1));
        add(new ImageViewer(image2));
        add(new ImageViewer(image3));
        add(new ImageViewer(image4));
        add(new ImageViewer(image5));
        add(new ImageViewer(image6));
    }

    public static void main(String[] args) {
        SixFlags frame = new SixFlags();
        frame.setTitle("SixFlags");
        frame.setLocationRelativeTo(null); // Center the frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setVisible(true);
    }
}
