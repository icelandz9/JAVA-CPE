import javax.swing.*;
import java.awt.*;
public class BorderLayoutTest {
public static void main(String[] args) {
Font fn = new Font("Microsoft Sans Serif", Font.BOLD, 14);
JFrame f = new JFrame("BorderLayOut Test");
JPanel p = new JPanel();
p.setLayout(new BorderLayout());
JButton a = new JButton("˹��"); JButton b = new JButton("�ͧ");
JButton c = new JButton("���"); JButton d = new JButton("���");
JButton e = new JButton("���"); JButton g = new JButton("ˡ");
JButton h = new JButton("��"); JButton i = new JButton("Ỵ");
JButton j = new JButton("���");
a.setFont(fn); b.setFont(fn); c.setFont(fn); d.setFont(fn); e.setFont(fn);
g.setFont(fn); h.setFont(fn); i.setFont(fn); j.setFont(fn);
JPanel p1 = new JPanel(); p1.setLayout(new BorderLayout());
JPanel p2 = new JPanel(); p2.setLayout(new BorderLayout());
p.add(p1, BorderLayout.NORTH);
p1.add(a, BorderLayout.WEST);
p1.add(b, BorderLayout.CENTER);
p1.add(c, BorderLayout.EAST);
p.add(d, BorderLayout.WEST);
p.add(p2, BorderLayout.CENTER);
p2.add(e, BorderLayout.NORTH);
p2.add(g, BorderLayout.CENTER);
p2.add(h, BorderLayout.SOUTH);
p.add(i, BorderLayout.EAST); p.add(j, BorderLayout.SOUTH);
f.add(p);
f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
f.setSize(200, 180);
f.setVisible(true);
}
}