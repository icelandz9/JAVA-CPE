import javax.swing.*;
public class TestButtonIcons extends JFrame {
public static void main(String[] args) {
// Create a frame and set its properties
JFrame frame = new TestButtonIcons();
frame.setTitle("ButtonIcons");
frame.setSize(200, 100);
frame.setLocationRelativeTo(null); // Center the frame
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
frame.setVisible(true);
}
public TestButtonIcons() {
ImageIcon usIcon = new ImageIcon("D:\\/SWU/CPE121/4.jpg");
ImageIcon caIcon = new ImageIcon("D:\\/SWU/CPE121/3.jpg");
ImageIcon ukIcon = new ImageIcon("D:\\/SWU/CPE121/2.jpg");
JButton jbt = new JButton("Click it", usIcon);
jbt.setPressedIcon(caIcon);
jbt.setRolloverIcon(ukIcon);
add(jbt);
}
}

//public TestButtonIcons() {
//ImageIcon usIcon = new ImageIcon("d:\\/cpe320/usIcon.gif");
//ImageIcon caIcon = new ImageIcon("d:\\/cpe320/caIcon.gif");
//ImageIcon ukIcon = new ImageIcon("d:\\/cpe320/ukIcon.gif");
//JButton jbt = new JButton("Click it", usIcon);
//jbt.setHorizontalAlignment(AbstractButton.RIGHT);
//jbt.setVerticalAlignment(AbstractButton.TOP);
//jbt.setPressedIcon(caIcon);
//jbt.setRolloverIcon(ukIcon);
//add(jbt);
//}
//}
//public TestButtonIcons() {
//ImageIcon usIcon = new ImageIcon("d:\\/cpe320/usIcon.gif");
//ImageIcon caIcon = new ImageIcon("d:\\/cpe320/caIcon.gif");
//ImageIcon ukIcon = new ImageIcon("d:\\/cpe320/ukIcon.gif");
//JButton jbt = new JButton("Click it", usIcon);
//jbt.setHorizontalTextPosition(AbstractButton.LEFT);
//jbt.setPressedIcon(caIcon);
//jbt.setRolloverIcon(ukIcon);
//add(jbt);
//}
//}