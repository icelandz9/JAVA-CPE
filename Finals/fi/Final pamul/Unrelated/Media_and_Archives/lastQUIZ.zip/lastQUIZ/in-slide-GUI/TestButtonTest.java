import javax.swing.*;
public class TestButtonTest {
public static void main(String args[]) {
JFrame f = new JFrame("Button Test");
JPanel p = new JPanel();
Icon ani = new ImageIcon("D:\\/SWU/CPE121/4.jpg");
JButton b1 = new JButton("Detail",ani);
JButton b2 = new JButton("Close");
p.add(b1); p.add(b2);
f.add(p);
f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
f.setSize(300, 400);
f.setVisible(true);
}
}
