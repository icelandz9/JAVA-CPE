import javax.swing.*;
import java.awt.*;
public class TestImageIcon extends JFrame {
private ImageIcon usIcon = new ImageIcon("D:\\/SWU/CPE121/1.jpg");
private ImageIcon myIcon = new ImageIcon("D:\\/SWU/CPE121/2.jpg");
private ImageIcon frIcon = new ImageIcon("D:\\/SWU/CPE121/3.jpg");
private ImageIcon ukIcon = new ImageIcon("D:\\/SWU/CPE121/4.jpg");
public TestImageIcon() {
setLayout(new GridLayout(1, 4, 5, 5));
add(new JLabel(usIcon));
add(new JLabel(myIcon));
add(new JButton(frIcon));
add(new JButton(ukIcon));
}
/** Main method */
public static void main(String[] args) {
TestImageIcon frame = new TestImageIcon();
frame.setTitle("TestImageIcon");
frame.setSize(500, 125);
frame.setLocationRelativeTo(null); // Center the frame
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
frame.setVisible(true);
}
}