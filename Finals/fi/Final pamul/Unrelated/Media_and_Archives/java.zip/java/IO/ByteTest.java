import java.io.*;
import java.util.Scanner;
public class ByteTest {
  public static void main(String[] args) {
    String fname = ("e:\\ByteData.txt"); 
    FileOutputStream f_out = null;
    try {
      f_out = new FileOutputStream(fname);
      int c;
      System.out.println("Read from KB");
      System.out.println("===========================");
      do {
        System.out.print("Enter Data : ");
        c = new Scanner(System.in).nextInt();
        if (c != 0) f_out.write(c);
      } while (c != 0);
    }
    catch (IOException e){
      System.out.println(e);
    }
    finally {
      try {
        if (f_out != null)
          f_out.close();
        System.out.println("Data are saved to File : \n" + fname);
        System.out.println("===========================");
      }
      catch (IOException e){
        System.out.println(e);
      }
    }
    FileInputStream f_in = null;
    try {
      f_in = new FileInputStream(fname);
      System.out.println("Read Data from File : \n" + fname);
      System.out.println("==========================="); int c;
      while ((c = f_in.read()) != -1){
        System.out.printf("%-3d", c);
        System.out.println(); }}
    catch (IOException e){
      System.out.println(e);
    }
    finally {
      try {
        if (f_in != null)
          f_in.close();
        System.out.println("===========================");
      }
      catch (IOException e) {
        System.out.println(e);
      }
    }
  }
}