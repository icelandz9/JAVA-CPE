public class calquiz4_2
{
  
}