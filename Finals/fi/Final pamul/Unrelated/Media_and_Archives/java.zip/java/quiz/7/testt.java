import java.util.Scanner;
public class testt
{
  public static void main(String[] args)
  {
    Scanner input= new Scanner(System.in);
    System.out.println("Enter your choice:");
    String choice = input.nextLine();
    System.out.println("Enter your message :");
    String str = input.nextLine();
    char[] cho= new char[choice.length()];
    char[] x= new char[str.length()];
    for(int i = 0;i<choice.length();i++)
    {
      cho[i] = choice.charAt(i); 
    }
    for(int i = 0;i<choice.length();i++)
    {
      x[i] = choice.charAt(i); 
    }
    int sum = cho[0]-x[0];
    System.out.println(sum);
  }
}
    