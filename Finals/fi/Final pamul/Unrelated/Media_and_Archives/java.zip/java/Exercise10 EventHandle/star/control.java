import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class control extends JFrame
{
  StarPanel1 st1 = new StarPanel1();
  StarPanel2 st2 = new StarPanel2();
  HexagonPanel1 hp = new HexagonPanel1();
  JButton jbtEnlarge = new JButton("Enlarge");
  JButton jbtShrink = new JButton("Shrink");
  JPanel p = new JPanel();
  JPanel pbt = new JPanel();
  JPanel p1 = new JPanel();
  public control()
  {
    p1.add(hp);
    p.setLayout(new BorderLayout());
    pbt.add(jbtEnlarge); pbt.add(jbtShrink);
    add(pbt,BorderLayout.SOUTH);
    add(hp,BorderLayout.CENTER);
    //add(p);
    jbtEnlarge.addActionListener(new EnlargeListener());
    jbtShrink.addActionListener(new ShrinkListener());
    
  }
  public static void main(String[] args) 
  {
    control frame = new control();
    frame.setTitle("Star");
    frame.setLocationRelativeTo(null); // Center the frame
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(200,200);
    frame.setVisible(true);
  }
  class EnlargeListener implements ActionListener
  {
    public void actionPerformed(ActionEvent e)
    {
      hp.enlarge();
    }
  }
    class ShrinkListener implements ActionListener
  {
    public void actionPerformed(ActionEvent e)
    {
      hp.shrink();
    }
  }
  class HexagonPanel1 extends JPanel { 
   private int x, y, xCenter, yCenter , radius=5;       // x, y coordinate   
    public int plusX = 0;    public int plusY = 0;
    @Override
    protected void paintComponent(Graphics g) {
      super.paintComponent(g);    
      int x1 = getWidth() / 8;      int y1 = getHeight() / 8; 
      int x2 = getWidth() / 4;      int y2 = getHeight() / 4; 
      int x3 = getWidth() / 2;      int y3 = getHeight() / 2;
      //int radius = (int)(Math.min(getWidth(), getHeight()) * 0.4);

      // Add points to the polygon
      xCenter = x3 + plusX;        yCenter = y3 + plusY;
      
    // Create a Polygon object
    g.setColor(Color.GREEN);
    Polygon polygon = new Polygon();  
    polygon.addPoint(xCenter + radius, yCenter);
    polygon.addPoint((int)(xCenter + radius *
       Math.cos(2 * Math.PI / 6)), (int)(yCenter - radius *
       Math.sin(2 * Math.PI / 6)));
    polygon.addPoint((int)(xCenter + radius *
           Math.cos(2 * 2 * Math.PI / 6)), (int)(yCenter - radius *
       Math.sin(2 * 2 * Math.PI / 6)));
    polygon.addPoint((int)(xCenter + radius *
       Math.cos(3 * 2 * Math.PI / 6)), (int)(yCenter - radius *
       Math.sin(3 * 2 * Math.PI / 6)));
    polygon.addPoint((int)(xCenter + radius *
       Math.cos(4 * 2 * Math.PI / 6)), (int)(yCenter - radius *
       Math.sin(4 * 2 * Math.PI / 6)));
    polygon.addPoint((int)(xCenter + radius *
       Math.cos(5 * 2 * Math.PI / 6)), (int)(yCenter - radius *
       Math.sin(5 * 2 * Math.PI / 6)));
    g.drawPolygon(polygon);
    }
    public void enlarge()//enlarge hexapolygon
  {
    radius++;
    repaint();
  }
    public void shrink()//shrink hexapolygon
  {
    radius--;
    repaint();
  }
  }   
}