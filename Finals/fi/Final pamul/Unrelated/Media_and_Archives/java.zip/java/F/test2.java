import java.util.Scanner;
 
public class test2 {
  public static void main (String[] args){
  Scanner sn = new Scanner(System.in);
  System.out.print("Please enter a decimal value(0000-9999)");
  int a = sn.nextInt();
  int a0 = a/2;
  int b0 = a%2;
  
  int a1 = a0/2;
  int b1 = a0%2;
  
  int a2 = a1/2;
  int b2 = a1%2;
  
  int a3 = a2/2;
  int b3 = a2%2;
  
  int a4 = a3/2;
  int b4 = a3%2;
  
  int a5 = a4/2;
  int b5 = a4%2;
  
  int a6 = a5/2;
  int b6 = a5%2;
  
  int a7 = a6/2;
  int b7 = a6%2;
  
  int a8 = a7/2;
  int b8 = a7%2;
  
  int a9 = a8/2;
  int b9 = a8%2;
  
  int a10 = a9/2;
  int b10 = a9%2;
  
  int a11 = a10/2;
  int b11 = a10%2;
  
  int a12 = a11/2;
  int b12 = a11%2;
  
  int a13 = a12/2;
  int b13 = a12%2;
  
  int a14 = a13/2;
  int b14 = a13%2;
  
  int b15 = a14%2;
  System.out.println("binary is " +b15+b14+b13+b12+" "+b11+b10+b9+b8+" "+b7+b6+b5+b4+" "+b3+b2+b1+b0);
  sn.close();
  }
}